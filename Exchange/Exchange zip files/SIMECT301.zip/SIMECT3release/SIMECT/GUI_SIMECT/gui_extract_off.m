set(handles.pushbutton15,'Enable','off');
set(handles.pushbutton16,'Enable','off');
set(handles.pushbutton17,'Enable','off');
set(handles.pushbutton31,'Enable','off');
set(handles.pushbutton33,'Enable','off');
set(handles.pushbutton35,'Enable','off');
