hv=[handles.popupmenu59 handles.popupmenu97 handles.popupmenu119 handles.popupmenu118 handles.popupmenu125 handles.popupmenu124];
hi=[handles.popupmenu103 handles.popupmenu102 handles.popupmenu121 handles.popupmenu120 handles.popupmenu127 handles.popupmenu126];
hd=[handles.popupmenu105 handles.popupmenu106 handles.popupmenu117 handles.popupmenu116 handles.popupmenu123 handles.popupmenu122];
