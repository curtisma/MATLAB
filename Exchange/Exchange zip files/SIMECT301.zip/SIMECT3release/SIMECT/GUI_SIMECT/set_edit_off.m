function set_edit_off(numedit)
    set(numedit,'Enable','off');
    set(numedit,'String','');
