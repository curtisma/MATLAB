function set_check_on(numedit)
    set(numedit,'Enable','on');
    set(numedit,'Value',0);
