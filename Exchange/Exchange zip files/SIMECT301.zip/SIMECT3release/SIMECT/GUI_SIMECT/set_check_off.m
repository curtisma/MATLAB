function set_check_off(numedit)
    set(numedit,'Enable','off');
    set(numedit,'Value',0);
