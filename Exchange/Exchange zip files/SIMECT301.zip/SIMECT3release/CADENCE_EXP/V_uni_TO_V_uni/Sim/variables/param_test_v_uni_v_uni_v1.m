ind=0 ;
param=[];

ind=ind+1 ;
param(ind).nam='w1';
param(ind).min=1e-05;
param(ind).max=5e-05;
param(ind).npt=5;

ind=ind+1 ;
param(ind).nam='l1';
param(ind).min=3.5e-07;
param(ind).max=5.5e-07;
param(ind).npt=5;

ind=ind+1 ;
param(ind).nam='I0';
param(ind).min=0.0001;
param(ind).max=0.0005;
param(ind).npt=5;
