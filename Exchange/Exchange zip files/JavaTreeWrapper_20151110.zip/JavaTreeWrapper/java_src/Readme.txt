This folder contains the Java source code and the netbeans project. You need Java Development Kit SE (JDK SE) with NetBeans to make edits.

Notes:
================
Package name must be "UIExtrasTree".

The required compile time libraries must be included in the project settings:
<matlabroot>\java\jarext\jide\jide-common.jar